﻿namespace pro2.ModelsDTO
{
    public class FlightUI
    {
        public int flightId {  get; set; }

        public FlightUI(int flightId)
        {
            this.flightId = flightId;
        }

    }
}
