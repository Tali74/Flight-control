﻿using Microsoft.AspNetCore.SignalR;
using System.Security.Cryptography.X509Certificates;

namespace pro2.SignalR
{
    public class AirportHub : Hub
        
    {
        public AirportHub ( )
        {

        }
    }
}
