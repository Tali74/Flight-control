export interface IFlight {
  flightId: number;
}
